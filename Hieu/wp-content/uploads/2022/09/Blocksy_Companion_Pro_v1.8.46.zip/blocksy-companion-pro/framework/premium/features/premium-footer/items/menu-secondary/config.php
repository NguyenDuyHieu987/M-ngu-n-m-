<?php

$config = [
	'name' => __('Footer Menu 2', 'blocksy-companion'),
	'typography_keys' => ['footerMenuFont'],
	'selective_refresh' => ['menu']
];

