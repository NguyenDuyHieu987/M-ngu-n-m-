<?php

$config = [
	'name' => __('Menu 3', 'blocksy'),
	'typography_keys' => ['headerMenuFont', 'headerDropdownFont'],
    'devices' => ['desktop'],
	'selective_refresh' => ['menu'],
	'excluded_from' => ['offcanvas']
];

