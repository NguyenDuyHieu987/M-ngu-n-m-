<?php

$config = [
	//  translators: This is a brand name. Preferably to not be translated
	'name' => _x('Custom Fonts', 'Extension Brand Name', 'blocksy-companion'),
	'description' => __('Upload an unlimited number of custom fonts or variable fonts and use them throughout Blocksy and your favorite page builder.', 'blocksy-companion'),
	'pro' => true
];