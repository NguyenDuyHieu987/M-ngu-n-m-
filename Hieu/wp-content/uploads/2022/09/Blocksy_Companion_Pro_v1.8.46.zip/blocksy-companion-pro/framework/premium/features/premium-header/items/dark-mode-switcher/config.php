<?php

$config = [
	'enabled' => false,
	'name' => __('Dark Mode', 'blocksy-companion'),
];

