<?php

$config = [
	//  translators: This is a brand name. Preferably to not be translated
	'name' => _x('Newsletter Subscribe', 'Extension Brand Name', 'blocksy-companion'),
	'description' => __('Easily capture new leads for your newsletter with the help of a widget, shortcode or even a block inserted on your pages or posts.', 'blocksy-companion')
];