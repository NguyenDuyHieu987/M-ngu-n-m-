<?php

$config = [
	'name' => __('Widget Area', 'blocksy-companion'),
];

